import cv2
import pandas as pd
import numpy as np
import streamlit as st

# Load color dataset
color_data = pd.read_csv("colors.csv")

def get_color_name(R, G, B):
    """Find the closest matching color name from dataset."""
    min_dist = float("inf")
    closest_color = "Unknown"
    for index, row in color_data.iterrows():
        distance = np.sqrt((R - row["Red"])**2 + (G - row["Green"])**2 + (B - row["Blue"])**2)
        if distance < min_dist:
            min_dist = distance
            closest_color = row["Color"]
    return closest_color

# Streamlit UI
st.title("Color Detection Application")
uploaded_file = st.file_uploader("Upload an image", type=["jpg", "png", "jpeg"])

if uploaded_file:
    # Read image
    image = cv2.imdecode(np.frombuffer(uploaded_file.read(), np.uint8), 1)
    st.image(image, caption="Uploaded Image", use_column_width=True)

    # Click on image to detect color
    st.write("Click on the image to detect color:")
    x = st.slider("X-coordinate", 0, image.shape[1]-1)
    y = st.slider("Y-coordinate", 0, image.shape[0]-1)

    # Get color at pixel
    B, G, R = image[y, x]
    color_name = get_color_name(R, G, B)

    # Display results
    st.write(f"Detected Color: **{color_name}**")
    st.write(f"RGB: ({R}, {G}, {B})")
    st.markdown(f"<div style='width:100px; height:50px; background-color:rgb({R},{G},{B});'></div>", unsafe_allow_html=True)